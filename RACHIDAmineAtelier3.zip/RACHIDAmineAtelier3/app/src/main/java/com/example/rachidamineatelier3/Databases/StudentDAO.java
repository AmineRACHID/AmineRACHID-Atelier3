package com.example.rachidamineatelier3.Databases;

import java.util.List;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface StudentDAO {

    @Insert
    void inserData(StudentsTable studentsTable);

    @Query("SELECT * FROM studentstable")
    List<StudentsTable> selectAll();
}
