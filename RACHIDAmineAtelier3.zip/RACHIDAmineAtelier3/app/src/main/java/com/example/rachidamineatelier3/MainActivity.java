package com.example.rachidamineatelier3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.rachidamineatelier3.Helper.DatabaseHelper;

public class MainActivity extends AppCompatActivity {

    EditText Nom_tv,Prenom_tv;
    DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helper = DatabaseHelper.getInstance(this);
        Nom_tv = findViewById(R.id.Nom_tv);
        Prenom_tv = findViewById(R.id.Prenom_tv);
    }

    public void submitData(View view) {
        if (!Nom_tv.getText().toString().isEmpty() && !Prenom_tv.getText().toString().isEmpty())
            helper.addNewStudent(Nom_tv.getText().toString(),Prenom_tv.getText().toString());
    }

    public void showData(View view) {
        startActivity(new Intent(this,DataViewerActivity.class));
    }
}