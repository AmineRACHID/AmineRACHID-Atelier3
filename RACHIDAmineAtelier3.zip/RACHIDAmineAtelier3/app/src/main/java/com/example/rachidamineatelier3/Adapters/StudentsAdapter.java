package com.example.rachidamineatelier3.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.rachidamineatelier3.DataViewerActivity;
import com.example.rachidamineatelier3.Databases.StudentsTable;
import com.example.rachidamineatelier3.R;

import java.util.List;

public class StudentsAdapter extends RecyclerView.Adapter<StudentsAdapter.ViewHolder> {

    Context context;
    View view;
    List<StudentsTable> studentsTableList;

    public StudentsAdapter(List<StudentsTable> studentsTableList) {
        this.studentsTableList = studentsTableList;
    }

    public StudentsAdapter(Context context){
        this.context = context;
    }

    public StudentsAdapter(Context context, List<StudentsTable> studentsTableList) {
        this.context = context;
        this.studentsTableList = studentsTableList;
    }


//    public StudentsAdapter(Context context) {
//        this.context = context;
//    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(context).inflate(R.layout.rv_layout,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (studentsTableList != null && studentsTableList.size() > 0){
            StudentsTable studentsTable = studentsTableList.get(position);
            holder.roll_no_tv.setText(String.valueOf(studentsTable.getId()));
            holder.Nom_tv.setText(studentsTable.getStu_name());
            holder.Prenom_tv.setText(studentsTable.getStu_standard());
        }
    }

    @Override
    public int getItemCount() {
        return studentsTableList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView roll_no_tv;
        TextView Nom_tv;
        TextView Prenom_tv;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            roll_no_tv = itemView.findViewById(R.id.roll_no_tv);
            Nom_tv = itemView.findViewById(R.id.Nom_tv);
            Prenom_tv = itemView.findViewById(R.id.Prenom_tv);
        }
    }
}
