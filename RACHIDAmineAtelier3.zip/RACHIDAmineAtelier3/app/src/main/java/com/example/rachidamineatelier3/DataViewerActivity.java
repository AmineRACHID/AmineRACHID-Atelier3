package com.example.rachidamineatelier3;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rachidamineatelier3.Adapters.StudentsAdapter;
import com.example.rachidamineatelier3.Databases.DatabaseClient;
import com.example.rachidamineatelier3.Databases.StudentsTable;
import com.example.rachidamineatelier3.Helper.DatabaseHelper;

import java.util.List;

public class DataViewerActivity extends AppCompatActivity {

    RecyclerView recycler_view;
    StudentsAdapter studentsAdapter;
    DatabaseHelper helper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_viewer);
        helper = DatabaseHelper.getInstance(this);
        recycler_view = findViewById(R.id.recycler_view);

        helper.getAllStudentsData();

    }
    public void setRecyclerView(List<StudentsTable> studentsTableList){
        recycler_view.setLayoutManager(new LinearLayoutManager(this));
        studentsAdapter = new StudentsAdapter(this,studentsTableList);
        recycler_view.setAdapter(studentsAdapter);
    }
}
